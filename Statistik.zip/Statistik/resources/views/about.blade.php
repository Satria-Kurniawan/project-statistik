
@extends('layout/main')

@section('title', 'About')

@section('container')
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Nama : Kadek Satria Kurniawan</h1>
        <h1>NIM : 1915101058</h1>
        <h1>Kelas : Ilmu Komputer 3B</h1>
      </div>
    </div>
  </div> 
@endsection
