
@extends('layout/main')

@section('title', 'Web Statistik')

@section('container')
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Halaman home</h1>
      </div>
    </div>
  </div> 
@endsection
