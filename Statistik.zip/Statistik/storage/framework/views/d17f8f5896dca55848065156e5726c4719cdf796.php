

<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <div class="col-10">
        <form action="/statistik" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group mt-3">
            <label for="nama">Nama Mahasiswa:</label>
            <input type="text" class="form-control" placeholder="Masukan nama" name="nama" id="nama">
          </div>
          <div class="form-group">
            <label for="nilai">Nilai:</label>
            <input type="number" class="form-control" placeholder="Masukan nilai" name="nilai" id="nilai">
          </div>
          <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </form> 
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\Statistik\resources\views//statistik/edit.blade.php ENDPATH**/ ?>