


<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Nama : Kadek Satria Kurniawan</h1>
        <h1>NIM : 1915101058</h1>
        <h1>Kelas : Ilmu Komputer 3B</h1>
      </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\Statistik\resources\views/about.blade.php ENDPATH**/ ?>