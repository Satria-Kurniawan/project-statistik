<?php $__env->startSection('title', 'Web Statistik'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Selamat datang di web statistik</h1>
        <a href="/">
            <img class="mt-5" src="img/statistik.jpg" width="60%" height="60%">
        </a>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\Statistik\resources\views/index.blade.php ENDPATH**/ ?>