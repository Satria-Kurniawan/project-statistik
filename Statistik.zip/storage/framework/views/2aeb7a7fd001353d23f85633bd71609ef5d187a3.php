<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <form action="/statistik/edit/<?php echo e($mahasiswa->id_mahasiswa); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group mt-3">
            <label for="nama">Nama Mahasiswa:</label>
            <input type="text" class="form-control" placeholder="Masukan nama" name="nama" id="nama" value="<?php echo e($mahasiswa->nama_mahasiswa); ?>">
          </div>
          <div class="form-group">
            <label for="nilai">Nilai:</label>
            <input type="number" class="form-control" placeholder="Masukan nilai" name="nilai" id="nilai" value="<?php echo e($mahasiswa->nilai_mahasiswa); ?>">
          </div>
          <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\Statistik\resources\views/statistik/edit.blade.php ENDPATH**/ ?>