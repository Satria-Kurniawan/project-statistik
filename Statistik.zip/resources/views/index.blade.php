
@extends('layout/main')

@section('title', 'Web Statistik')

@section('container')
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Selamat datang di web statistik</h1>
        <a href="/">
            <img class="mt-5" src="img/statistik.jpg" width="60%" height="60%">
        </a>
      </div>
    </div>
  </div>
@endsection
