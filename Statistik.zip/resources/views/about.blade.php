
@extends('layout/main')

@section('title', 'About')

@section('container')
  <div class="container">
    <div class="row">
      <div class="col-10">
        <h1>Kadek Satria Kurniawan</h1>
        <h5>satria.kurniawan@undiksha.ac.id</h5>
      </div>
    </div>
  </div>
@endsection
